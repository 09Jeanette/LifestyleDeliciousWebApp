package com.javaguides.lifestyledelicioswebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LifestyleDeliciosWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
